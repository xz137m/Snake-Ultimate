var canvas, ctx, minimapCanvas, minimapCtx;
var scoreElement, highScoreElement, coinsElement, rpElement, levelElement;
var menuOverlay, shopOverlay, guideOverlay, settingsOverlay, rebirthOverlay, slayerShopOverlay;
var startBtn, shopBtn, rebirthMenuBtn, guideBtn, settingsBtn, resetBtn, slayerShopBtn;
var closeShopBtn, closeRebirthBtn, doRebirthBtn, closeGuideBtn, closeSettingsBtn, closeSlayerShopBtn;
var toggleSoundBtn, toggleParticlesBtn, toggleRangeBtn, toggleGlowBtn, toggleBrightnessBtn, toggleQualityBtn;
var langEnBtn, langArBtn;
var progressFill, progressText, xpFill, xpText;